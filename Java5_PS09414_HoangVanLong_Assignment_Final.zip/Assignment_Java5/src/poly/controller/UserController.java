package poly.controller;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.transaction.Transactional;
import javax.websocket.server.PathParam;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import poly.entity.Users;

@Controller
@RequestMapping("account")
public class UserController {
	@Autowired
	SessionFactory f;

	@RequestMapping("show")
	@Transactional
	public String show(ModelMap model) {
		Session s = f.getCurrentSession();
		String hql = "from Users";
		Query qr = s.createQuery(hql);
		List<Users> list = qr.list();
		model.addAttribute("users", list);
		return "account/account";
	}



	@RequestMapping(value = "insert", method = RequestMethod.GET)
	public String insert(ModelMap model) {
		model.addAttribute("user",new Users());
		return "account/insert";
	}
	@RequestMapping(value = "insert", method = RequestMethod.POST)
	public String insert(ModelMap model, @ModelAttribute("user") Users user, BindingResult er) {
		Session s = f.openSession();
		Transaction tran = s.beginTransaction();
		try {
			if(user.getUsername().trim().length() == 0) {
				er.rejectValue("username", "user", "Username khong duoc de trong");
			}
			if(user.getPassword().trim().length() == 0) {
				er.rejectValue("password", "user", "Pass khong duoc de trong");
			}
			if(user.getFullname().trim().length() == 0) {
				er.rejectValue("fullname", "user", "fullname khong duoc de trong");
			}
			if(er.hasErrors()) {
				
				return "account/insert";
			}
			else {
				s.save(user);
				tran.commit();
				model.addAttribute("message","Insert thanh cong");
			}
			
		} catch (Exception e) {
			tran.rollback();
			model.addAttribute("message","Insert that bai");
		}
		finally {
			
			s.close();
		}
		return "redirect:show.htm";
	}
	

	@RequestMapping(params="btnDelete", value = "show")
	public String insert(ModelMap model, HttpServletRequest rq) {
		Session s = f.openSession();
		Transaction tran = s.beginTransaction();
		String username = rq.getParameter("txtUser");
		try {
			Users d =(Users) s.get(Users.class,username);
			s.delete(d);
			tran.commit();
			model.addAttribute("message","delete thanh cong");
		} catch (Exception e) {
			tran.rollback();
			model.addAttribute("message","delete that bai");
		}
		finally {
			
			s.close();
		}
		return "redirect:show.htm";
	}
	
	@RequestMapping(params="btnUpdate", value = "show")
	public String update(ModelMap model, HttpServletRequest rq) {
		Session s = f.openSession();
		Transaction tran = s.beginTransaction();
		String username = rq.getParameter("txtUser");
		String password = rq.getParameter("txtPass");
		String fullname = rq.getParameter("txtFullname");
		
		try {
			Users d =(Users) s.get(Users.class,username);
			d.setPassword(password);
			d.setFullname(fullname);
			s.update(d);
			tran.commit();
			model.addAttribute("message","update thanh cong");
		} catch (Exception e) {
			tran.rollback();
			model.addAttribute("message","update that bai");
		}
		finally {
			
			s.close();
		}
		return "redirect:show.htm";
	}
	
}