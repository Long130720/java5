package poly.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.transaction.Transactional;
import javax.validation.Valid;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.validation.Errors;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import poly.entity.Departs;

@Controller
@RequestMapping("depart")

public class DepartController {
	@Autowired
	SessionFactory f;

	@RequestMapping("show")
	@Transactional
	public String show(ModelMap model) {
		Session s = f.getCurrentSession();
		String hql = "from Departs";
		Query qr = s.createQuery(hql);
		List<Departs> list = qr.list();
		model.addAttribute("depart", list);
		return "depart/depart";
	}

	@RequestMapping(params = "btnDelete", value = "show")
	public String delete(ModelMap model, HttpServletRequest rq) {
		Session s = f.openSession();
		Transaction tran = s.beginTransaction();
		String id = rq.getParameter("txtId");
		try {
			Departs d = (Departs) s.get(Departs.class, id);
			s.delete(d);
			tran.commit();
			model.addAttribute("message", "delete thanh cong");
		} catch (Exception e) {
			tran.rollback();
			model.addAttribute("message", "delete that bai");
		} finally {

			s.close();
		}
		return "redirect:show.htm";
	}

	@RequestMapping(params = "btnUpdate", value = "show")
	public String update(ModelMap model, HttpServletRequest rq) {
		Session s = f.openSession();
		Transaction tran = s.beginTransaction();
		String id = rq.getParameter("txtId");
		String name = rq.getParameter("txtDepartName");

		try {
			Departs d = (Departs) s.get(Departs.class, id);
			d.setId(id);
			d.setName(name);
			s.update(d);
			tran.commit();
			model.addAttribute("message", "update thanh cong");
		} catch (Exception e) {
			tran.rollback();
			model.addAttribute("message", "update that bai");
		} finally {

			s.close();
		}
		return "redirect:show.htm";
	}

	@RequestMapping(params = "btnInsert", value = "show", method = RequestMethod.POST)
	public String insert(ModelMap model, HttpServletRequest rq, @ModelAttribute("dp") Departs dp,
			BindingResult errors) {
		Session s = f.openSession();
		Transaction tran = s.beginTransaction();
		String id = rq.getParameter("txtId1");
		String name = rq.getParameter("txtDepartName1");

		try {

			dp.setId(id);
			dp.setName(name);
			if(dp.getId().trim().length() == 0) {
				errors.rejectValue("id", "dp","Id cant't is Emtity");
			}
			if(dp.getName().trim().length() == 0) {
				errors.rejectValue("name", "dp","Name cant't is Emtity");
			}
			if(errors.hasErrors()) {
				model.addAttribute("message", "Vui long sua loi");
			}
			else {
				s.save(dp);
				tran.commit();
				model.addAttribute("message", "Insert thanh cong");
			}
			

		} catch (Exception e) {
			tran.rollback();
			model.addAttribute("message", "Insert that bai");
		} finally {
			s.close();
		}

		return "redirect:show.htm";
	}
}
