package poly.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.transaction.Transactional;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import poly.entity.Users;

@Controller

public class LoginController {
	@Autowired
	SessionFactory f;

	@RequestMapping("login")
	public String login() {
		return "login";
	}
	
	@RequestMapping(params = "btnLogin", value = "login")
	@Transactional
	public String actionLogin(HttpServletRequest rq, ModelMap model,HttpSession session, @ModelAttribute("user") Users u) {
		String path = null;
		String user = rq.getParameter("txtUsername");
		String pass = rq.getParameter("txtPassword");
		Session s = f.getCurrentSession();
		String hql = "FROM Users where Username = :user";
		Query qr = s.createQuery(hql);
		
		qr.setParameter("user", user);
		u = (Users) qr.uniqueResult();
		if (u == null) {
			model.addAttribute("message", "Tài khoảng không tồn tại");
			path = "redirect:index.jsp";
		} else {

			if (pass.equalsIgnoreCase(u.getPassword())) {
				session.setAttribute("user", u);
				path = "redirect:/home/index.htm";
			} else {
				path = "redirect:index.jsp";
				model.addAttribute("message", "Sai password");
			}
		}
		return path;
	}
	

}
