package poly.controller;

import java.io.File;
import java.text.SimpleDateFormat;

import java.util.List;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;


import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import poly.entity.Departs;
import poly.entity.Staffs;

@Controller
@RequestMapping("staff")
@Transactional
public class StaffController {
	@Autowired
	SessionFactory f;

	@RequestMapping("show")

	public String show(ModelMap model) {
		return "staff/staff";
	}
	
	@ModelAttribute("staffs")
	public List<Staffs> staff(ModelMap model) {
		Session s = f.getCurrentSession();
		String hql = "from Staffs";
		Query qr = s.createQuery(hql);
		List<Staffs> list = qr.list();
		return list;
	}

	@RequestMapping("insert")
	public String insert(ModelMap model) {
		model.addAttribute("insert", "staff/insert");
		return "staff/insert";
	}

	@Autowired
	ServletContext context;

	@RequestMapping(params = "btnSave", value = "insert")
	public String insert(ModelMap model, HttpServletRequest rq, @RequestParam("photo") MultipartFile photo) {
		String id = rq.getParameter("id");
		String name = rq.getParameter("name");
		String email = rq.getParameter("email");
		String birthday = rq.getParameter("birthday");
		String cell = rq.getParameter("cell");
		String gender = rq.getParameter("gender");
		String salary = rq.getParameter("salary");
		String note = rq.getParameter("note");
		String depart = rq.getParameter("depart");
		Staffs st = new Staffs();
		Departs dp = new Departs();
		Session s = f.openSession();
		Transaction tr = s.beginTransaction();
		try {
			
			st.setId(id);
			st.setName(name);
			boolean gt = true;
			if (gender.equalsIgnoreCase("false")) {
				gt = false;
			}
			st.setGender(gt);

			st.setBirthday(new SimpleDateFormat("yyyy-MM-dd").parse(birthday.trim()));
			if (photo.isEmpty()) {
				st.setPhoto("khongcoanh.jpg");
			} else {
				photo.transferTo(new File(context.getRealPath("/files/" + photo.getOriginalFilename())));
				st.setPhoto(photo.getOriginalFilename());
			}

			st.setEmail(email);
			st.setPhone(cell);
			st.setSalary(Float.parseFloat(salary));
			st.setNotes(note);
			dp.setId(depart);
			st.setDepart(dp);
			s.save(st);
			tr.commit();
			model.addAttribute("message", "Insert Thành Công !");
			System.out.println("try");
		} catch (Exception e) {
			tr.rollback();
			e.printStackTrace();
			System.out.println("cath");
			model.addAttribute("message", "Insert Thất bại !");
		} finally {
			s.close();
			System.out.println(depart);

		}
		return "redirect:show.htm";
	}
	
	@RequestMapping(params="btnDelete", value = "show")
	public String delete(ModelMap model, HttpServletRequest rq) {
		Session s = f.openSession();
		Transaction tran = s.beginTransaction();
		String id = rq.getParameter("id");
		try {
			Staffs d =(Staffs) s.get(Staffs.class,id);
			s.delete(d);
			tran.commit();
			model.addAttribute("message","delete thanh cong");
		} catch (Exception e) {
			tran.rollback();
			model.addAttribute("message","delete that bai");
		}
		finally {
			
			s.close();
		}
		return "redirect:show.htm";
	}
	@RequestMapping("update")
	public String update(){	
		return "staff/update";
	}

    @RequestMapping("/edit/{id}")
    public String editUser(ModelMap model,
            @PathVariable("id") String id){
        Session se = f.openSession();
        Staffs d = (Staffs) se.get(Staffs.class, id);
        model.addAttribute("use", d);
        return "staff/update";
    }
	@RequestMapping(params = "btnUpdate", value = "update")
	public String update(ModelMap model, HttpServletRequest rq, @RequestParam("photo") MultipartFile photo) {
		String id = rq.getParameter("id");
		String name = rq.getParameter("name");
		String email = rq.getParameter("email");
		String birthday = rq.getParameter("birthday");
		String cell = rq.getParameter("cell");
		String gender = rq.getParameter("gender");
		String salary = rq.getParameter("salary");
		String note = rq.getParameter("note");
		String depart = rq.getParameter("depart");
		String hinh = rq.getParameter("hinh");
		Departs dp = new Departs();
		Session s = f.openSession();
		Transaction tr = s.beginTransaction();
		try {
			Staffs st = (Staffs) s.get(Staffs.class, id);
			st.setId(id);
			st.setName(name);
			boolean gt = true;
			if (gender.equalsIgnoreCase("false")) {
				gt = false;
			}
			st.setGender(gt);

			st.setBirthday(new SimpleDateFormat("yyyy-MM-dd").parse(birthday.trim()));
			if (photo.isEmpty()) {
				st.setPhoto(hinh);
			} else {
				photo.transferTo(new File(context.getRealPath("/files/" + photo.getOriginalFilename())));
				st.setPhoto(photo.getOriginalFilename());
			}

			st.setEmail(email);
			st.setPhone(cell);
			st.setSalary(Float.parseFloat(salary));
			st.setNotes(note);
			dp.setId(depart);
			st.setDepart(dp);
			s.update(st);
			tr.commit();
			model.addAttribute("message", "Cập nhật Thành Công !");
			System.out.println("try");
		} catch (Exception e) {
			tr.rollback();
			e.printStackTrace();
			System.out.println("cath");
			model.addAttribute("message", "Cập nhật  Thất bại !");
		} finally {
			s.close();

		}
		return "redirect:update.htm";
	}

	@RequestMapping("report")
	public String report(ModelMap model) {
		Session session = f.getCurrentSession();
		String hql = "SELECT r.staff.Id," + " SUM(case when r.Type=1 then 1 else 0 end),"
				+ " SUM(case when r.Type=0 then 1 else 0 end)" + " FROM Records r GROUP BY r.staff.Id";
		Query query = session.createQuery(hql);
		List<Object[]> list = query.list();
		model.addAttribute("arrays", list);
		return "staff/report";
	}
	@ModelAttribute("depart")
	public List<Departs> getDeparts() {
		Session session = f.getCurrentSession();
		String hql = " FROM Departs";
		Query query = session.createQuery(hql);
		List<Departs> list = query.list();
		return list;
	}
}
